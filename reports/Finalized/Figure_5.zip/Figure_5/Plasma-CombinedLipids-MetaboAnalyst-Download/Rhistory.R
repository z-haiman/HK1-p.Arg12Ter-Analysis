# PID of current job: 3971200
mSet<-InitDataObjects("conc", "stat", FALSE, 150)
mSet<-Read.TextData(mSet, "Replacing_with_your_file_path", "rowu", "disc");
mSet<-SanityCheckData(mSet)
mSet<-PerformSanityClosure (mSet);
mSet<-CheckContainsBlank(mSet)
mSet<-FilterVariable(mSet, "F", 20, "none", -1, "mean", 0, F,10.0)
mSet<-PreparePrenormData(mSet)
mSet<-Normalization(mSet, "NULL", "NULL", "NULL", ratio=FALSE, ratioNum=20)
mSet<-PlotNormSummary(mSet, "norm_0_", "png", 150, width=NA)
mSet<-PlotSampleNormSummary(mSet, "snorm_0_", "png", 150, width=NA)
mSet<-Ttests.Anal(mSet, F, 0.05, FALSE, TRUE, "fdr", FALSE)
mSet<-PlotTT(mSet, "tt_0_", "png", 150, width=NA)
mSet<-Ttests.Anal(mSet, F, 0.05, FALSE, FALSE, "raw", FALSE)
mSet<-PlotTT(mSet, "tt_1_", "png", 150, width=NA)
mSet<-SaveTransformedData(mSet)
